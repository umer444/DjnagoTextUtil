from django.http import HttpResponse
from django.shortcuts import render


def index(request):
    return render(request,'index.html')

def about(request):
    return render(request,'About.html')

def analyze(request):
    djtext=request.POST.get('text','defualt')
    punchation=request.POST.get('Punchation','off')
    Fullcapilize=request.POST.get('Fullcapilize','off')
    NewLine=request.POST.get('NewLine','off')

    analyzes = ''
    if punchation == "on":
        p = ''' !()-[]{};:'"\,<>./?@#$%^&*_~ '''
        analyzes=''
        for char in djtext:
            if char not in p:
                analyzes=analyzes+char

        parms={'purpose':"REMOVE PUNCTION",
               'analyze_text':analyzes}
        return render(request,"analyze.html",parms)

    elif Fullcapilize == "on":
        analyzes = ''
        for char in djtext:
         analyzes= analyzes + char.upper()

        parms = {'purpose': "FULL CAPITLIZE",
                 'analyze_text': analyzes}
        return render(request, "analyze.html", parms)

    elif NewLine == 'on':
        analyzes = ''
        for char in djtext:
            if djtext !="/n":
                analyzes=analyzes+char

        parms={'purpose':"LINE REMOVE",
               'analyzed':analyzes}
        return render(request,"analyze.html",parms)
    else:
        analyzes = djtext
        parms = {'purpose': "TEXT",
                 'analyze_text': analyzes}
        return render(request, "analyze.html", parms)

